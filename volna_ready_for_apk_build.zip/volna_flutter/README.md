# Волна — Android

## Самый простой способ получить APK
Этот проект подготовлен для автоматической сборки через GitHub Actions.

1. Создайте бесплатный аккаунт GitHub.
2. Создайте новый репозиторий и загрузите туда содержимое этого проекта.
3. Откройте вкладку **Actions**.
4. Выберите **Build Android APK**.
5. Нажмите **Run workflow**.
6. После завершения скачайте файл **volna-release-apk**.

APK можно установить на Samsung S25 Ultra.

## Локальная сборка
```bash
flutter pub get
flutter create --platforms=android .
flutter build apk --release
```
